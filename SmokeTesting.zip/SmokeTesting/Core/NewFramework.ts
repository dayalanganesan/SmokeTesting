

// interface IEmployee {
//     empCode: number;
//     empName: string;
//     getSalary: (number) => number; // arrow function
//     getManagerName(number): string; 
//     Do: Do;
// }

// interface Do {
// click: void;
 
// }
// export enum perform {
//     Click = "#click",
//     GetText = "#gettext",
// }

// export class objr {
//     homesceen: { xpath: string; };
//     constructor(){
//         this.homesceen ={ xpath: "123"}
//         "".add(1);
//     }
//     static home(){
//         return {
//             "homesceen":{ xpath: "123"}
//         }
//     }
// }

// declare global {
//     interface String {
//         add(length : number) : string;
//     }
// }

// interface String {
//     add(...strings: string[]): string;
//   }
  
//   String.prototype.add = function (...strings) {
//     return this + strings.join('');
//   };