
Steps to kick start
Install Node Js


run command "npm install -g selenium-webdriver"
run command "npm install selenium-webdriver"

